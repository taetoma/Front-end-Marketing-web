import React from 'react'

export default function Numbers() {
  return (
    <div className='px-40 md:px-16 sm:px-16 my-20  mt-36'>
        <h1 className='text-4xl font-semibold tracking-wider text-gray-500 text-center my-10 sm:text-4xl'>Till Now We have provided this number of services to.. </h1>
        <div className='grid grid-cols-3 sm:grid-cols-1 bg-secondary space-x-5 justify-center md:px-3 my-20 py-20'>
            <div className='items-center sm:mb-14'>
                <h1 className='text-7xl text-white mb-10 tracking-wider sm:mb-0'>449</h1>
                <h1 className='text-6xl md:text-5xl text-white '>Clients</h1>
            </div>
            <div className='items-center sm:mb-14'>
                <h1 className='text-7xl text-white mb-10 tracking-wider sm:mb-0'>785</h1>
                <h1 className='text-6xl md:text-5xl text-white '>Projects</h1>
            </div>
            <div className='items-center '>
                <h1 className='text-7xl text-white mb-10 tracking-wider sm:mb-0'>23</h1>
                <h1 className='text-6xl md:text-5xl text-white '>Location</h1>
            </div>

        </div>
    </div>
  )
}
