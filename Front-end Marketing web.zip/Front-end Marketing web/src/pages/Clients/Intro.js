import React from 'react'

export default function Intro() {
  return (
    <>
    <div className='grid grid-cols-2 md:grid-cols-2 sm:grid-cols-1 lg:grid-cols-1 px-20 items-center h-[500px] bg-primary min-w-full'>
        <div className='p-10 w-[600px] sm:w-[400px] md:w-[470px] md:-ml-16' >
        <lottie-player src="https://assets8.lottiefiles.com/packages/lf20_8pturyty.json"  background="transparent"  speed="1"  loop  autoplay></lottie-player>

        </div>
        <div className='flex flex-col text-start mx-8 md:mt-10 md:-mr-28'>
        <h1 className="text-7xl font-semibold text-white ">We <span className="text-secondary ">Work</span> together With our <span className="text-yellow-300">Clients</span></h1>
        
            <p className=" my-5 text-md text-gray-500  hover:bg-primary">to give real services you must add something which cannot be bought and that is sincerity and integrity </p>
        
        </div>
       

        </div>
    </>
  )
}
