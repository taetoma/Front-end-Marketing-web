import React from 'react'
import Layout from '../../component/Layout'
import Intro from './Intro'
import ClientList from './ClientList'
import Numbers from './Numbers'

export default function Clients() {
  return (
    <Layout>
    <Intro/>
    <ClientList/>
    <Numbers/>
    </Layout>
  )
}
