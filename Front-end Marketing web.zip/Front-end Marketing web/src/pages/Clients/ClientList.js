import React, { useState } from 'react'

export default function ClientList() {
  const [selectedClintIndex, setSelectedClientIndex] = useState(0)
  const clients = [
    {
      name: "Slack",
      logo: "images/slack.png",
      url: "https://www.tcs.com/",
      description:
        "Slack is a cloud-based set of tools and services that makes it easy to get work done. It’s built for teams of all sizes, and has a simple, beautiful design that’s easy to use and works great on any device.",
    },
    {
      name: "Twitter",
      logo: "images/twitter.png",
      url: "https://www.infosys.com/",
      description:
        "Twitter is a social networking service that enables users to send and read short 140-character messages called “tweets”.",
    },
    {
      name: "Instagram",
      logo: "images/instagram.png",
      url: "https://www.wipro.com/",
      description:
        "Instagram is a photo-sharing, video-sharing and communication service that is owned and operated by Facebook, Inc. It was created by Kevin Systrom and Mike Krieger, and launched in October 2010.",
    },
    {
      name: "Spotify",
      logo: "images/spotify.png",
      url: "https://www.hcl.com/",
      description:
        "Spotify is a music streaming service that offers a wide range of music genres, including rock, pop, country, electronic, and more. It was created by Swedish computer programmer and programmer Johan Liljegren in 2007.",
    },
    {
      name: "Messenger",
      logo: "images/messenger.png",
      url: "https://www.accenture.com/",
      description:
        "Messenger is a messaging app that enables users to communicate with their friends and family. It was created by Facebook in 2011.",
    },
    {
      name: "Cognizant",
      logo: "images/cognizant.png",
      url: "https://www.capgemini.com/",
      description:
        "Cognizant is a multinational technology company headquartered in Bengaluru, India. It is the largest Indian IT company by market capitalization.",
    },
    {
      name: "Github",
      logo: "images/github.png",
      url: "https://www.cognizant.com/",
      description:
        "GitHub is a web-based hosting service for version control of code using the distributed version control (DVCS) model. It was created by Linus Torvalds in 2005.",
    },

  ];
  const next = () => {
    if (selectedClintIndex / 2 !== 0) {
      setSelectedClientIndex(selectedClintIndex + 1)   
    } else{

      setSelectedClientIndex(selectedClintIndex + 2)
    }
  };

  const previous = () => {
    setSelectedClientIndex(selectedClintIndex - 2)
  };
  return (
    <>
      <div className='bg-primary py-40 rounded sm:py-64 rounded-b-full'></div>
      <div className='flex justify-center md:p-5 sm: items-center md: sm:space-x-0 md:space-x-0 space-x-16 mx-20 sm:mx-0 md:mx-0'>
        {selectedClintIndex !== 0 && (
          <i className="ri-arrow-left-s-line text-6xl hover:bg-primary md:hidden text-secondary sm:hidden border-2 border-gray-400 hover:border-secondary rounded-full" onClick={previous}></i>
        )}
        <div className='grid grid-cols-2 sm:grid-cols-1 md:space-x-3  sm:space-y-5 sm:space-x-0 space-x-16'>
          {[clients[selectedClintIndex], clients[selectedClintIndex + 1]].map((item) => (
            <div className=' bg-white -mt-44 border  shadow w-[500px] sm:w-72 md:w-auto sm: p-5'>
              <div className='flex space-x-10 sm:justify-center justify-between sm:px-5 mx-14 mb-4'>
                <h1 className='font-extrabold pt-12 text-xl text-primary'>{item.name}</h1>
                <img src={item.logo} alt="" className='h-32 w-32' />
              </div>
              <p className='text-gray-500 text-start'>{item.description}</p>
            </div>
          ))}
        </div>

        {selectedClintIndex <= 4 && (
          <i className="ri-arrow-right-s-line border-2 sm:hidden md:hidden text-6xl hover:bg-primary text-secondary  border-gray-400 hover:border-secondary rounded-full" onClick={next}></i>
        )}
      </div>

      <div className='flex justify-center mt-10'>
        <div className='flex space-x-2'>
          {[1, 2, 3, 4, 5, 6].map((item, index) =>(
            <div onClick={()=>setSelectedClientIndex(index)} 
            className={`rounded-full h-4 w-4 bg-gray-300 cursor-pointer transform hover:scale-105 duration-300 
            ${selectedClintIndex === index && "bg-primary h-6 w-6 border-4 border-primary"}`}>
            </div>
          ))}
        </div>
      </div>

    </>
  )
}
