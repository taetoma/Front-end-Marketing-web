import React from 'react'

export default function WyChosUs() {
    const items = [
        {
          title: "Innovative and Passionate",
          image: "images/innovation.png",
          description:
            "We are a team of creative and passionate designers and developers. We are fully aware of the importance of designing for the digital age and strive to deliver the best result for our clients.",
        },
        {
          title: "Good Return on Investment",
          image: "images/investment.png",
          description:
            "Working with us means providing your business with great savings. All our digital marketing and web development packages are being offered at competitive prices",
        },
        {
          title: "Seamless Customer Support",
          image: "images/customer-support.png",
          description:
            "We are always here to help you with any questions you may have. We are always here to help you with any questions you may have. We are always here to help you with any questions you may have.",
        },
      ];
  return (
    <>
<div className=' my-36 mx-28 '>
    <div className='bg-primary py-20 md:-mx-20 rounded-sm'>
         <h1 className='text-white md:text-7xl sm:text-6xl font-semibold tracking-wider text-8xl'>Why Choose Us..?</h1>
    </div>
   
    <div className='bg-white border w-full h-96 md:-ml-20 sm:h-[850px]  sm:w-[470px] md:w-[670px]'>

    </div>
    <div className='-mt-80 md:-mx-16 md:px-5 grid grid-cols-3 sm:-mt-[790px] gap-14 mx-20 md:gap-5 sm:grid-cols-1 md:grid-cols-3'>
        {items.map((item)=>(
            <div className='p-5  md:px-5 rounded-lg bg-white border border-t-secondary border-t-8 shadow flex flex-col space-y-5 items-center transform hover:scale-105 duration-300'>
                <img src={item.image} alt="" className='h-12 w-12' />
                <h1 className='font-semibold text-primary tracking-wider text-xl text-start'>{item.title}</h1>
                <p className='text-gray-400 text-sm text-start'>{item.description}</p>
            </div>
        ))}
     </div>
</div>
    </>
  )
}
