import React from 'react'
import Layout from '../../component/Layout'
import Intro from './Intro'
import WtWeDo from './WtWeDo'
import WyChosUs from './WyChosUs'

export default function About() {
  return (
    <Layout className="mb-44 px-20 sm:my-0">
   <Intro/>
   <WtWeDo/>
   <WyChosUs/>
    </Layout>
  )
}

