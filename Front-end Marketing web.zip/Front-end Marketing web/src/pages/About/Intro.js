import React from 'react'

export default function Intro() {
    return (
        <>
        <div className='about-intro h-screen '>
            
        </div>
        <div className='items-center sm:justify-start sm:items-start grid grid-cols-2 lg:grid-cols-1 md:grid-cols-1 min-h-screen sm:grid-cols-1 sm:mb-0 sm:pb-0'>
                <div className='transform -scale-x-100 z-10 flex sm:justify-start sm:-mt-24 justify-center h-[500px] w-[900px] sm:w-[600px] sm:-ml-20  -ml-28'>
                <lottie-player src="https://assets8.lottiefiles.com/packages/lf20_jkd8z4bj.json"  background="transparent"  speed="1" loop hover ='loop'   autoplay></lottie-player>



                </div>

                <div className='text-white lg:z-0 lg:text-primary md:text-primary sm:text-white  sm:items-start m-20 text z-20 md:z-0 sm:mx-12 sm:-mt-64 max-w-max sm:space-y-0 space-y-10 text-start'>
                    <h1 className='border-b-2 text-8xl sm:text-6xl tracking-wider sm:text-start md:-space-t-28 font-semibold'>TAETOMA</h1>
                    <h2 className=' text-gray-200 lg:text-gray-500 md:text-gray-500 md:-mt-20 lg:bg-slate-100 md:bg-slate-100 sm:bg-none -space-y-10 '>OLDER | STRONGER | WISER</h2>
                </div>
            </div>
            </>
    )
}
