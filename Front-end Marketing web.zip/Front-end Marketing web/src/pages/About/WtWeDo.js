import React from 'react'

export default function WtWeDo() {
    const items =   [ {
        title: "Web Development",
        icon: "images/web.png",
        description:
          "Web development is the work involved in developing a website for the Internet or an intranet.",
      },
      {
        title: "Mobile Development",
        icon: "images/mobile.png",
        description:
          "Mobile development is the work involved in developing a mobile application for mobile devices such as smartphones, tablets, and feature phones.",
      },
      {
        title: "Digital Marketing",
        icon: "images/digital-marketing.png",
        description:
          "Digital marketing is the work involved in developing a digital marketing strategy and developing a digital marketing plan.",
      },
  
      {
        title: "Graphic Design",
        icon: "images/graphicdesign.png",
        description:
          "Graphic design is the work involved in developing a digital marketing strategy and developing a digital marketing plan.",
      },
    ];
  return (
    <>
    <div className="z-20 sm:-mt-28">
     <h1 className='text-secondary my-10 mb-20 lg:text-7xl text-8xl sm:text-6xl sm:mx-4 sm:tracking-normal tracking-wider md:bg-slate-100 md:rounded-lg lg:-m font-semibold'>What We Do ?</h1>
     <div className='bg-primary max-w-screen-2xl h-80  rounded-md'>

     </div>
     <div className='-mt-52 sm:mx-10 md:mx-10 grid grid-cols-4 gap-10 mx-20 sm:grid-cols-1 md:grid-cols-2'>
        {items.map((item)=>(
            <div className='p-5 rounded-lg bg-white border shadow flex flex-col space-y-5 items-center transform hover:scale-105 duration-300'>
                <img src={item.icon} alt="" className='h-12 w-12' />
                <h1 className='font-semibold text-primary text-xl text-start'>{item.title}</h1>
                <p className='text-gray-500 text-start'>{item.description}</p>
            </div>
        ))}
     </div>
    
    </div>
    </>
  )
}
