import React from 'react'
import Layout from '../../component/Layout'
import Intro from './Intro'
import Stratigies from './Stratigies'
import WyMarketing from './WyMarketing'
export default function Home() {
  return (
    <Layout>
      <div className='mx-32 mb-44 sm:mx-0 sm:mb-0 sm:p-5'>
        <Intro/>
    <Stratigies/>
    <WyMarketing/>
      </div>
    
    </Layout>
  )
}
