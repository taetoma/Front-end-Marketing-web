import React from 'react'

export default function WyMarketing() {
    return (
        <div>
            <h1 className='text-primary text-7xl sm:text-5xl font-semibold tracking-widest'>WHY <span className='text-secondary'>MARKETING</span> ?</h1>
            <div className='h-[500px]'>
                <lottie-player src="https://assets8.lottiefiles.com/packages/lf20_mftd0tzf.json" background="transparent" speed="1" loop autoplay>
                </lottie-player>
            </div>
            <div className=' text-start my-16 sm:mb-0 text-primary sm:mx-3 sm:justify-start'>
            <p className='font-semibold sm:py-4'>Marketing is a highly competitive and rewarding field. Businesses across every industry rely on marketing professionals to generate awareness of their brand and increase sales of their products and services. If you’re a strategic and creative problem-solver, then a career in marketing could be right for you.</p>

            <h1 className='text-secondary border-b-2  border-primary mx-64 pb-4 text-center sm:mx-2 my-10 font-semibold sm:text-start text-xl'>Here are three reasons why you should consider pursuing a degree in marketing :</h1>

            <h1 className='text-md font-semibold py-2 pt-4'>Marketing is a diverse career choice: </h1>
            <p>As a<span className='text-secondary'> marketing student,</span> you’re exposed to a variety of different subject areas and disciplines. For example, marketers need to understand basic business principles as well as elements of psychology to understand consumer behavior. Marketing graduates are able to apply their skills to a variety of different tasks, such as developing advertisements, creating websites, writing content, handling consumer research and/or leading marketing strategy. As a marketing student, you have the opportunity to find the type of marketing career that aligns with your interests and strengths.</p>
            <h1 className='text-md font-semibold sm:pt-7 sm:py-4 py-2 pt-4'>Your skills are always in demand:</h1>
            <p>A <span className='text-secondary'>degree in marketing </span>
               ensures that you know how to communicate effectively and think creatively — invaluable skills in today’s job market. In fact, college graduates with strong communication and computer skills have the best career prospects and greater opportunities for career advancement. Marketing students develop critical research, analysis and problem-solving skills that can be applied to marketing careers in sales, advertising, product development and public relations for both companies and agencies.
            </p>

            <h1 className='text-md font-semibold py-2 pt-4 sm:pt-7 sm:py-4'>The futur of marketing is digital:</h1>
            <p className='border-b-2 border-primary pb-20'><span className='text-secondary'>Digital technology </span>
               is changing the way that we interact with our world, and that includes the way consumers engage with companies and brands. Successful marketers are both analytic and creative since they use data to understand consumer behavior, develop brand strategy and make informed marketing decisions. It’s also important for marketers to understand how to leverage technology to motivate and engage consumers. If you’re a detail-oriented problem solver with a knack for thinking outside the box, then a career in marketing might be the perfect fit for you.
            </p></div>
        </div>
    )
}
