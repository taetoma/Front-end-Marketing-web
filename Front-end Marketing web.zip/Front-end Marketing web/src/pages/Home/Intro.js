import React from 'react'

export default function Intro() {
  return (
    <>
     <div className='grid grid-cols-2 sm:text-start items-center tracking-wider sm:grid-cols-1 '>
        <div className='flex flex-col items-end sm:items-center'>
        <h1 className="text-7xl sm:text-5xl font-semibold text-primary sm:py-3 ">The Best <span className="text-secondary  sm:text-5xl  text-8xl">Marketing</span></h1>
        <h1 className="text-4xl sm:text-5xl sm:pt-0 py-4 font-semibold text-primary pt-5">Doesn't feel like Markting</h1>
        
            <button className="px-20 my-5 rounded-md max-w-max mx-10 py-5 bg-secondary sm:px-4 sm:items-end sm:ml-40 text-white text-xl hover:bg-primary">Get started</button>
        
        </div>

        <div className='p-10 ' >
            <lottie-player src="https://assets4.lottiefiles.com/packages/lf20_um8dbzhc.json"  background="transparent"  speed="2" 
            
            loop 
            autoplay>
            
              </lottie-player>
        </div>
        </div>
    </>
  )
}
