import React from 'react'

export default function Stratigies() {
const str = [
    {
       title: "CONTENT MARKETING",
       description: "marketing leverages database marketing, behavioral advertising and analytics to target consumers precisely and create loyalty programs. !",
       image : "images/content-marketing.png"
      },
    {
       title: "INPOUND MARKTING",
       description: "Inbound is when customers initiate contact with the marketer in response to various methods used to gain their attention. These methods include email, events, content and web design.",
       image : "images/inbound-marketing.png"
      },
    {
       title: "SOCIAL MEDIA",
       description: "A common and powerful tool for marketers at all levels. Email marketing has a role in direct, digital, inbound and outbound marketing efforts. It helps marketers with lead generation, brand awareness, relationship building and more.!",
       image : "images/social-media.png"
      },
    {
       title: "SEARCH ENGINE OPTIMIZATION",
       description: "SEO marketing is a subset of digital marketing that involves the optimization of websites and web pages for major search engines like Google. As these search engines became a predominant way of finding just about anything, various practices have emerged to help organizations improve the visibility of their digital assets.!",
       image : "images/seo.png"
      },
 ]
  return (
    <>
       <div className='sm:pr-5'>
        <h1 className='text-5xl sm:py-10 sm:text-3xl font-semibold text-primary'>
          Want to boost your bussniness growth..?
        </h1>
        <h1 className='text-7xl sm:text-5xl text-primary mt-5 font-semibold'>The <span className='text-secondary'>SOLUTION </span>is here...</h1>
        <p className='text-gray-500 text-xl p-5 sm:text-start sm:justify-start sm:py-10'>Marketers have shifted their efforts online because it tends to be significantly less expensive. Many online advertising spaces are free to use. Companies can upload videos to Youtube or start a blog for no cost at all. Other outlets like official websites or paid search marketing cost a fraction of what a major television advertising campaign would.</p>
    </div>

    <div className='grid grid-cols-2 my-16 sm:grid-cols-1 sm:pr-5'>
    {str.map(item=>{
      return <div className='text-start border  border-primary p-7 sm:mx-2 mx-16 my-8 transform hover:scale-105 duration-300'>
        <h1 className='text-2xl border text-center -mt-11 bg-white font-semibold py-4  mb-3 border-primary text-secondary'>{item.title}</h1>
        <img src={item.image} alt="" className='h-20 w-20'/>
        <p className='text-gray-500 mt-3 hover:text-primary'>{item.description}</p>
      </div>
    })}
    </div>
    </>
   
  )
}
