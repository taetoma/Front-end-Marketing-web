import React from 'react'

export default function Address() {
    return (
        <>
        <div className='mx-20 sm:-m-1 md:mx-8'>
            <div className=' bg-primary text-white flex-col basis-1/3 px-10 rounded-2xl py-12 my-16'>
                <h1 className='text-white text-5xl text-center sm:text-4xl'>Get in touch</h1>
                <p className='text-xs font-light text-gray-400 mt-4 text-start' >TAE_TOMA is a company that provides marketing services to businesses. These services can include market research, advertising, public relations, itc..</p>
               
                <div className='flex space-x-5 py-6 justify-start items-center'>
                    <div className='text-secondary bg-gray-600 border border-gray-500 rounded-lg p-3'>
                        <i class="ri-map-pin-2-fill"></i>
                    </div>
                    <div className='text-sm tracking-wider text-start'>
                       <h1 className='text-xl'>Visit US</h1>
                        <p className='font-light text-gray-300'>Al-Gharbia, Tanta</p>
                        <p className='font-light text-gray-300'>Egypt</p>
                    </div>
                </div>
                <div className='flex space-x-5 py-6 justify-start items-center'>
                    <div className='text-secondary bg-gray-600 border border-gray-500 rounded-lg p-3'>
                    <i class="ri-mail-line"></i>                    </div>
                    <div className='text-sm tracking-wider text-start'>
                        <h1 className='text-xl'>Mail US</h1>
                        <p className='font-light text-gray-300'>ttae4525@gmail.com</p>
                    </div>
                </div>
                <div className='flex space-x-5 py-6 justify-start items-center'>
                    <div className='text-secondary bg-gray-600 border border-gray-500 rounded-lg p-3'>
                    <i class="ri-customer-service-2-line"></i>                    </div>
                    <div className='text-sm tracking-wider text-start'>
                    <h1 className='text-xl'>Call US</h1>
                        <p className='font-light text-gray-300'>+201206305695</p>
                    </div>
                </div>

        
                <div className="grid grid-cols-5 space-x-2 py-7">
                                <a  className='text-secondary bg-gray-600 border border-gray-500 rounded-s-2xl p-3' href="https://twitter.com/twittermena?lang=ar"><i class="ri-twitter-fill"></i></a>
                                <a  className='text-secondary bg-gray-600 border border-gray-500 rounded-lg p-3'href="https://ar-ar.facebook.com/login/device-based/regular/login/"><i class="ri-facebook-circle-fill"></i></a>
                                <a  className='text-secondary bg-gray-600 border border-gray-500 rounded-lg p-3'href="https://www.linkedin.com/login/ar"><i class="ri-linkedin-fill"></i></a>
                                <a  className='text-secondary bg-gray-600 border border-gray-500 rounded-lg p-3'href="https://www.instagram.com/"><i class="ri-instagram-fill"></i></a>
                                <a  className='text-secondary bg-gray-600 border border-gray-500 rounded-e-lg p-3'href="https://www.youtube.com/"><i class="ri-youtube-fill"></i></a>
                            </div>

                {/* <p className='text-sm '>Taetoma's Free, Easy-to-Use Email Builder Has The Tools You Need to Grow Your Business.</p> */}


            </div>
            </div>
        </>
    )
}
