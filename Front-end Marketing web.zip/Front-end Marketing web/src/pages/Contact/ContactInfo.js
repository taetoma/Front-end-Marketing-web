import React from 'react'

export default function ContactInfo() {
  return (
    <>
      <div classname="">
        <div className='mt-16 sm:w-auto sm:px-8  md:w-[400px] md:px-5 md:mx-0 text-start my-20 sm:my-10 mx-10 px-20 w-[850px] py-12 bg-red-50 border border-gray-500 rounded-xl flex-col basis-2/3'>
          <h2 className="text-6xl font-semibold leading-7 text-start text-primary sm:text-4xl md:text-4xl">Send a message</h2>

          <p className=" text-sm leading-6 text-gray-600  mt-4 font-light py-4 text-start">Use a permanent address where you can receive mail.</p>
          <div className='grid grid-cols-5 space-x-4'>
            <hr className='h-3  bg-secondary rounded-xl mb-10 ' />
            <hr className='h-3 w-6 bg-secondary rounded-xl mb-10 ' />
          </div>
          <div className="grid grid-cols-2 md:gap-6">
            <div className="relative z-0 w-full mb-6 group">
              <input type="text" name="floating_first_name" id="floating_first_name" className="block  focus:bg-gray-100 py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-100 appearance-none dark:text-primary dark:border-gray-600   peer" placeholder=" " required />
              <label htmlFor="floating_first_name" className="peer-focus:font-medium absolute text-sm text-gray-200 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-105 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">First name</label>
            </div>
            <div className="relative z-0 w-full mb-6 group">
              <input type="text" name="floating_last_name" id="floating_last_name" className="block  focus:bg-gray-200 py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-100 appearance-none dark:text-primary dark:border-gray-600   peer" placeholder=" " required />
              <label htmlFor="floating_last_name" className="peer-focus:font-medium absolute text-sm text-gray-200 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-105 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Last name</label>
            </div>
          </div>
          <div className="relative z-0 w-full mb-6 group">
            <input type="email" name="floating_email" id="floating_email" className="block focus:bg-gray-200 py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-100 appearance-none dark:text-primary dark:border-gray-600   peer" placeholder=" " required />
            <label htmlFor="floating_email" className="peer-focus:font-medium absolute text-sm text-gray-200 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500  peer-placeholder-shown:scale-105 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Email address</label>
          </div>
          <div className="relative z-0 w-full mb-6 group">
            <input type="password" name="floating_password" id="floating_password" className="block focus:bg-gray-200 py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-100 appearance-none dark:text-primary dark:border-gray-600   peer" placeholder=" " required />
            <label htmlFor="floating_password" className="peer-focus:font-medium absolute text-sm text-gray-200 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 focus:bg-gray-100 peer-placeholder-shown:scale-105 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Password</label>
          </div>

          <div className="relative z-0 w-full mb-6 group">
            <input type="tel" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" name="floating_phone" id="floating_phone" className="block py-2.5 px-0 w-full text-sm text-gray-500 focus:bg-gray-300 bg-transparent border-0 border-b-2 border-gray-100 appearance-none dark:text-primary dark:border-gray-600   peer" placeholder=" " required />
            <label htmlFor="floating_phone" className="peer-focus:font-medium absolute text-sm text-gray-200 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-105 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Phone number (123-456-7890)</label>
          </div>

          <div className="relative z-0 w-full mb-6 group">
            <textarea id="message" rows={3} className="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-100 appearance-none dark:text-primary focus:bg-gray-100 dark:border-gray-600   peer" placeholder=" " required />
            <label htmlFor="floating_phone" className="peer-focus:font-medium absolute text-sm text-gray-200 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600  peer-focus:dark:text-blue-500  peer-placeholder-shown:scale-105 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Leave Your message...</label>
          </div>
          <div className='flex items-end justify-end md:justify-start sm:justify-start py-5 w-[700px]'>
            <button type="submit" className="flex text-white bg-primary hover:bg-secondary border-4 border-gray-300 font-medium rounded-full text-sm px-16 sm:w-auto  py-2.5 text-center  ">Submit</button>

          </div>

        </div>

      </div>
    </>
  )
}
