import React from 'react'
import Layout from '../../component/Layout'
import Address from './Address'
import ContactInfo from './ContactInfo'

export default function Contact() {
  return (
    <Layout className="px-20">
      <div className="flex flex-row sm:flex-col md:px-10">
        <Address/>
        <ContactInfo/>
      </div>
    </Layout>

  )
}
