import {BrowserRouter, Routes, Route} from 'react-router-dom'
import './App.css';
import About from './pages/About';
import Contact from './pages/Contact';
import Clients from './pages/Clients';
import Home from './pages/Home';
import 'remixicon/fonts/remixicon.css'

function App() {
  return (
    <>

    <div className="App">
 
      <BrowserRouter>
      
        <Routes className="sm">

            <Route path='/' element={<Home />} />
            <Route path='/about' element={<About />} />
            <Route path='/contact' element={<Contact />} />
            <Route path='/clients' element={<Clients />} />

        </Routes>
     
      
      </BrowserRouter> 
      <div className=' '>
   <div className='flex py-16 justify-center -my-24 sm:mb-20 mb-32 bg-gray-600 '>
   
          <h1 className='text-md font-semibold tracking-wider text-gray-300'>Designed and Developer by @<span className='text-secondary text-lg'>Fatma Mahmoud</span>..</h1>
        </div>
    </div>
    </div>
    </>
  );
}

export default App;
