import React from 'react'
import { Link, useLocation } from 'react-router-dom'

export default function Layout({ children }) {
  
  const location = useLocation()
  const menuitem = [
    {
      title: 'Home',
      path: '/',
      icon: "ri-home-office-fill",
    },
    {
      title: 'About',
      path: '/about',
      icon: 'ri-information-line',
    },
    {
      title: 'Clients',
      path: '/clients',
      icon: 'ri-user-search-fill',
    },
    {
      title: 'Contact',
      path: '/contact',
      icon: "ri-mail-send-fill",
    },
  ]
  return (
    <>  
   

      <div className=' mb-44'>
        {children}
      </div>


      {/* footer */}
      
      <div className='fixed bottom-10 sm:bottom-0 left-0 right-0'>
        <div className='flex w-full justify-center sm:w-auto'>
          
            {menuitem.map((item, index) => (
              <div className='flex flex-col justify-center'>
              {location.pathname === item.path && (
              <div className='flex flex-col items-center '>
                <div className='h-5 w-10 sm:hidden bg-primary rounded-t-full'>

                </div>
                <div className='h-5  w-20 bg-primary rounded-t-full'>
                <i className={` ${item.icon} text-secondary mx-2 text-xl`}></i>
                </div>
              </div>)} 
              <div className={`px-20  bg-primary sm:px-3 md:px-10 py-5 sm:py-4 ${index === 0 && "rounded-l"} ${index === menuitem.length - 1 && "rounded-r"}
            `}>
               {location.pathname!== item.path && <i className={` ${item.icon} text-secondary mx-2 sm:mx-0 md:mx-1 text-xl`}></i>}
                <Link className='text-secondary text-xl ' to={`${item.path}`} >{item.title}</Link>
              </div>
              </div>
            ))}
        </div>
      </div>

    </>

  )
}
